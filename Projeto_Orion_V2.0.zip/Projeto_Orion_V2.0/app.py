from flask import Flask, render_template, request, redirect, url_for, session
import mysql.connector

app = Flask(__name__)
app.secret_key = 'Proj3to_0rion'

# Conexão com o MariaDB/MySQL
def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        port=3306,  # Porta usada no Senai
        user="root",
        password="root01",
        database="ProjetoOrion",
    )

# Página inicial → login
@app.route('/')
def index():
    return redirect(url_for('login'))

# Página ADM
@app.route('/adm', methods=['GET'])
def adm():
    if 'usuario' not in session or session['usuario']['role'] != 'adm':
        return redirect(url_for('login'))
    return render_template('adm_home.html')

# Página Usuário
@app.route('/usuario', methods=['GET'])
def usuario():
    if 'usuario' not in session or session['usuario']['role'] != 'user':
        return redirect(url_for('login'))
    return render_template('user_home.html')

# Cadastro de Funcionário
@app.route('/cadastrar_funcionario', methods=['POST'])
def cadastrar_funcionario():
    nome_completo = request.form.get('nome')
    email = request.form.get('email')
    re = request.form.get('re')
    senha = request.form.get('senha')
    setor = request.form.get('setor')
    turno = request.form.get('turno')
    grau = request.form.get('grau')
    auditorias = request.form.getlist('auditoria[]')
    tipoAuditoria = ','.join(auditorias)
    nome_usuario = nome_completo

    conexao = get_db_connection()
    cursor = conexao.cursor()

    # Verifica duplicados
    cursor.execute(
        "SELECT re FROM funcionarios WHERE re = %s OR email = %s OR nome_usuario = %s",
        (re, email, nome_usuario)
    )
    if cursor.fetchone():
        cursor.close()
        conexao.close()
        return render_template('registroU.html', error="RE, e-mail ou nome já cadastrados!")

    sql = """
    INSERT INTO funcionarios
    (nome_completo, email, re, nome_usuario, senha, setor, turno, grau, tipoAuditoria, role)
    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    """
    valores = (nome_completo, email, re, nome_usuario, senha, setor, turno, grau, tipoAuditoria, "user")
    cursor.execute(sql, valores)
    conexao.commit()
    cursor.close()
    conexao.close()

    return redirect(url_for('adm'))

# Login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        re = request.form.get('re')
        senha = request.form.get('senha')

        conexao = get_db_connection()
        cursor = conexao.cursor(dictionary=True)
        cursor.execute(
            "SELECT * FROM funcionarios WHERE re = %s AND senha = %s",
            (re, senha)
        )
        usuario = cursor.fetchone()
        cursor.close()
        conexao.close()

        if usuario:
            session['usuario'] = usuario
            if usuario.get('role') == 'adm':
                return redirect(url_for('adm'))
            else:
                return redirect(url_for('usuario'))
        else:
            return render_template('Login.html', error="RE ou senha incorretos")

    return render_template('Login.html')

# Cadastro de Usuário
@app.route('/cadastroUsuarios')
def cadastroU():
    return render_template('registroU.html')

# Cadastro de Máquina
@app.route('/cadastroMaquinas')
def cadastroM():
    return render_template('registroM.html')

# Gerenciar Funcionários
@app.route('/gerenciar')
def gerenciar():
    conexao = get_db_connection()
    cursor = conexao.cursor(dictionary=True)
    cursor.execute("SELECT * FROM funcionarios")
    funcionarios = cursor.fetchall()
    cursor.close()
    conexao.close()
    return render_template('geren.html', funcionarios=funcionarios)

# Editar Funcionário
@app.route('/editar_funcionario/<re>', methods=['GET'])
def editar_funcionario(re):
    conexao = get_db_connection()
    cursor = conexao.cursor(dictionary=True)
    cursor.execute("SELECT * FROM funcionarios WHERE re = %s", (re,))
    funcionario = cursor.fetchone()
    cursor.close()
    conexao.close()

    if not funcionario:
        return "Funcionário não encontrado", 404

    return render_template('editar_funcionario.html', funcionario=funcionario)

@app.route('/salvar_funcionario/<re>', methods=['POST'])
def salvar_funcionario(re):
    nome = request.form['nome-func']
    status = request.form['status-func']
    setor = request.form['depto-func']
    email = request.form['email-func']
    grau = request.form['grau-escalonamento']

    conexao = get_db_connection()
    cursor = conexao.cursor()
    cursor.execute("""
        UPDATE funcionarios
        SET nome_completo=%s, _status=%s, setor=%s, email=%s, grau=%s
        WHERE re=%s
    """, (nome, status, setor, email, grau, re))
    conexao.commit()
    cursor.close()
    conexao.close()

    return redirect('/gerenciar')

# Gerenciar Máquinas
@app.route('/gerenciar_maquinas')
def gerenciar_maquinas():
    conexao = get_db_connection()
    cursor = conexao.cursor(dictionary=True)
    cursor.execute("SELECT * FROM maquinas")
    maquinas = cursor.fetchall()
    cursor.close()
    conexao.close()
    return render_template('gerenciar_maquinas.html', maquinas=maquinas)

# Logout
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
