document.addEventListener('DOMContentLoaded', function () {
    const toggle = document.getElementById('toggle-senha');
    if (toggle) {
        toggle.addEventListener('click', function () {
            const passwordInput = document.getElementById('senha');
            const icon = this.querySelector('i');
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
    }

    const toggleConfirm = document.getElementById('toggle-confirmar-senha');
    if (toggleConfirm) {
        toggleConfirm.addEventListener('click', function () {
            const passwordInput = document.getElementById('confirmar_senha');
            const icon = this.querySelector('i');
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        });
    }

    const form = document.getElementById('employee-form');
    if (form) {
        form.addEventListener('submit', function (e) {
            let isValid = true;

            // Nome
            const nome = document.getElementById('nome');
            if (!nome.value.trim()) { document.getElementById('nome-error').style.display = 'block'; nome.style.borderColor = '#dc3545'; isValid = false; } 
            else { document.getElementById('nome-error').style.display = 'none'; nome.style.borderColor = '#28a745'; }

            // Email
            const email = document.getElementById('email');
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email.value)) { document.getElementById('email-error').style.display = 'block'; email.style.borderColor = '#dc3545'; isValid = false; }
            else { document.getElementById('email-error').style.display = 'none'; email.style.borderColor = '#28a745'; }

            // RE
            const re = document.getElementById('re');
            if (!re.value.trim()) { document.getElementById('re-error').style.display = 'block'; re.style.borderColor = '#dc3545'; isValid = false; }
            else { document.getElementById('re-error').style.display = 'none'; re.style.borderColor = '#28a745'; }

            // Senha
            const senha = document.getElementById('senha');
            if (senha.value.length < 8) { document.getElementById('senha-error').style.display = 'block'; senha.style.borderColor = '#dc3545'; isValid = false; }
            else { document.getElementById('senha-error').style.display = 'none'; senha.style.borderColor = '#28a745'; }

            // Confirmar senha
            const confirmarSenha = document.getElementById('confirmar_senha');
            if (confirmarSenha.value !== senha.value) { document.getElementById('confirmar-senha-error').style.display = 'block'; confirmarSenha.style.borderColor = '#dc3545'; isValid = false; }
            else { document.getElementById('confirmar-senha-error').style.display = 'none'; confirmarSenha.style.borderColor = '#28a745'; }

            // Setor
            const setor = document.getElementById('setor');
            if (setor.value === '') { document.getElementById('setor-error').style.display = 'block'; setor.style.borderColor = '#dc3545'; isValid = false; }
            else { document.getElementById('setor-error').style.display = 'none'; setor.style.borderColor = '#28a745'; }

            // Turno
            const turno = document.getElementById('turno');
            if (turno.value === '') { document.getElementById('turno-error').style.display = 'block'; turno.style.borderColor = '#dc3545'; isValid = false; }
            else { document.getElementById('turno-error').style.display = 'none'; turno.style.borderColor = '#28a745'; }

            // Grau
            const grau = document.getElementById('grau');
            if (grau.value === '') { document.getElementById('grau-error').style.display = 'block'; grau.style.borderColor = '#dc3545'; isValid = false; }
            else { document.getElementById('grau-error').style.display = 'none'; grau.style.borderColor = '#28a745'; }

            // Auditorias
            const auditoriaCheckboxes = document.querySelectorAll('input[name="auditoria[]"]');
            const algumaSelecionada = Array.from(auditoriaCheckboxes).some(cb => cb.checked);
            const toggleButton = document.getElementById('checkbox-toggle-button');
            const checkboxError = document.getElementById('grau1-error');
            if (!algumaSelecionada) { checkboxError.style.display = 'block'; toggleButton.classList.remove('valid'); toggleButton.classList.add('invalid'); isValid = false; }
            else { checkboxError.style.display = 'none'; toggleButton.classList.remove('invalid'); toggleButton.classList.add('valid'); }

            updateCheckboxLabel();

            // Se inválido, previne envio
            if (!isValid) {
                e.preventDefault();
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
            // se válido -> formulário é enviado normalmente para Flask
        });
    }
});

function toggleCheckboxes() {
    const checkboxList = document.getElementById('checkbox-list');
    const toggleButton = document.querySelector('.checkbox-toggle');
    const isOpen = checkboxList.style.display === 'block';
    checkboxList.style.display = isOpen ? 'none' : 'block';
    toggleButton.classList.toggle('focused', !isOpen);
    toggleButton.classList.toggle('open', !isOpen);
}

function updateCheckboxLabel() {
    const checkboxes = document.querySelectorAll('input[name="auditoria[]"]');
    const label = document.getElementById('checkbox-label');
    const checkedCount = Array.from(checkboxes).filter(cb => cb.checked).length;
    if (checkedCount === 0) { label.textContent = 'Selecione as Auditorias'; }
    else if (checkedCount === 1) { label.textContent = '1 auditoria selecionada'; }
    else { label.textContent = `${checkedCount} auditorias selecionadas`; }
}

const auditoriaCheckboxes = document.querySelectorAll('input[name="auditoria[]"]');
auditoriaCheckboxes.forEach(cb => { cb.addEventListener('change', updateCheckboxLabel); });

// Função que leva à tela de edição
function editarFuncionario(re) {
    window.location.href = `/editar_funcionario/${re}`;
}

document.addEventListener("scroll", function () {
            const topPanel = document.querySelector(".top-panel");
            if (window.scrollY > 50) {
                topPanel.classList.add("shrink");
            } else {
                topPanel.classList.remove("shrink");
            }
        });