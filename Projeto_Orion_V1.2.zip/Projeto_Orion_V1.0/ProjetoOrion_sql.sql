projetoorionCREATE DATABASE IF NOT EXISTS ProjetoOrion;
USE ProjetoOrion;

-- Cria tabela funcionários compatível com o formulário (nome, email, re, nome_usuario, senha, setor, turno, grau, role)
CREATE TABLE IF NOT EXISTS funcionarios (
    re VARCHAR(100) NOT NULL PRIMARY KEY,
    nome_completo VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    nome_usuario VARCHAR(100) UNIQUE,
    senha VARCHAR(255) NOT NULL,
    setor VARCHAR(60),
    turno VARCHAR(20),
    grau VARCHAR(60),
    tipoAuditoria VARCHAR(60),
    role ENUM('adm','user') NOT NULL DEFAULT 'user',
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Exemplo de inserção de admin (troque senha para algo seguro)
INSERT INTO funcionarios (nome_completo, email, re, nome_usuario, senha, setor, turno, grau, role)
VALUES ('Administrador', 'admin@empresa.com', 'ADM001', 'adm', 'admin1234', 'administracao', '1', 'auditor', 'adm');

-- Exemplo de usuário comum
INSERT INTO funcionarios (nome_completo, email, re, nome_usuario, senha, setor, turno, grau)
VALUES ('Funcionario Exemplo', 'func@empresa.com', 'USU001', 'user', 'usuario1234', 'producao', '2', 'auditor');

SELECT * FROM funcionarios

DROP TABLE funcionarios
DROP DATABASE registro_funcionario


ALTER TABLE funcionarios ADD COLUMN _status VARCHAR(10)

INSERT INTO Funcionarios (nome_completo, email, re, nome_usuario, senha, setor, turno, grau) VALUES
('Ricardo Pereira', 'ricardo.silva@chriscintos.com.br', 1507234, 'Ricardo Pereira', 'SENHA_INICIAL', 'ESTAMPARIA', NULL, 'ENCARREGADO'),
('Robson de Jesus', 'robson.goncalves@chriscintos.com.br', 1506677, 'Robson de Jesus', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE'),
('Rogerio Marcato', 'rogerio.marcato@chriscintos.com.br', 110774, 'Rogerio Marcato', 'SENHA_INICIAL', 'TECELAGEM / TINTURARIA', NULL, 'SUPERVISOR'),
('Sandra da Cunha', 'sandra.pereira@chriscintos.com.br', 43931, 'Sandra da Cunha', 'SENHA_INICIAL', 'MON FECHO', NULL, 'SUPERVISOR'),
('Sandra de Souza', 'sandra.souza@chriscintos.com.br', 1507754, 'Sandra de Souza', 'SENHA_INICIAL', 'EXCELÊNCIA OPERACIONAL', NULL, 'ANALISTA'),
('Sandra Gomes', 'sandra.jesus@chriscintos.com.br', 1506256, 'Sandra Gomes', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE'),
('Sheila Verissimo', 'sheila.silva@chriscintos.com.br', 1506335, 'Sheila Verissimo', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE'),
('Silvana Serafin', 'silvana.veloso@chriscintos.com.br', 1508129, 'Silvana Serafin', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'ENCARREGADO'),
('Simone Reimberg', 'simone.pereira@chriscintos.com.br', 1509455, 'Simone Reimberg', 'SENHA_INICIAL', 'MON FECHO', NULL, 'ENCARREGADO'),
('Suely Coutinho', 'suely.coutinho@chriscintos.com.br', 47896, 'Suely Coutinho', 'SENHA_INICIAL', 'MON RETRATOR', NULL, 'ENCARREGADO'),
('Talita Soares', 'talita.soares@chriscintos.com.br', 1506563, 'Talita Soares', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'ANALISTA'),
('Tamires Monteiro', 'tamires.silva@chriscintos.com.br', 1506314, 'Tamires Monteiro', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE'),
('Telma Bolognani', 'telma.bolognani@chriscintos.com.br', 1507808, 'Telma Bolognani', 'SENHA_INICIAL', 'MON RETRATOR', NULL, 'ENCARREGADO'),
('Uelinton Ramos', 'uelinton.ramos@chriscintos.com.br', 1505998, 'Uelinton Ramos', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE'),
('Vânia de Oliveira', 'vania.oliveira@chriscintos.com.br', 1501845, 'Vânia de Oliveira', 'SENHA_INICIAL', 'MON FECHO', NULL, 'ENCARREGADO'),
('Wellington Alves', 'wellington.alves@chriscintos.com.br', 1506386, 'Wellington Alves', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE'),
('Wilson Hermogenes', 'wilson.hermogenes@chriscintos.com.br', 1506980, 'Wilson Hermogenes', 'SENHA_INICIAL', 'TRATAMENTO TÉRMICO', NULL, 'ENCARREGADO'),
('Levi Gonçalves', 'levi.costa@chriscintos.com.br', 1500835, 'Levi Gonçalves', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'GERENTE'),
('Lohan Ribas', 'lohan.ribas@chriscintos.com.br', 1507845, 'Lohan Ribas', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE'),
('Lucas Remédio', 'lucas.remedio@chriscintos.com.br', 1508444, 'Lucas Remédio', 'SENHA_INICIAL', 'ENG. MANUFATURA', NULL, 'GERENTE'),
('Mª Liliane de Sousa', 'maria.oliveira@chriscintos.com.br', 1507107, 'Mª Liliane de Sousa', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE'),
('Marcelo Santos', 'marcelo.jesus@chriscintos.com.br', 1508122, 'Marcelo Santos', 'SENHA_INICIAL', 'MON FECHO', NULL, 'ENCARREGADO'),
('Marcio Riva', 'marcio.riva@chriscintos.com.br', 1507735, 'Marcio Riva', 'SENHA_INICIAL', 'INJETORA', NULL, 'SUPERVISOR'),
('Marcos Guimarães', 'marcos.guimaraes@chriscintos.com.br', 1507861, 'Marcos Guimarães', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE'),
('Marcos Roberto', 'marcos.menezes@chriscintos.com.br', 37575, 'Marcos Roberto', 'SENHA_INICIAL', 'FUNDIÇÃO', NULL, 'ENCARREGADO'),
('Matheus Correa', 'matheus.francisco@chriscintos.com.br', 1508484, 'Matheus Correa', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE'),
('Michele Betania', 'michele.borges@chriscintos.com.br', 1504252, 'Michele Betania', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE'),
('Milena Carla', 'milena.oliveira@chriscintos.com.br', 1501640, 'Milena Carla', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE'),
('Mônica Gomes', 'monica.nascimento@chriscintos.com.br', 1501633, 'Mônica Gomes', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'ANALISTA'),
('Mozer Machado', 'mozer.araujo@chriscintos.com.br', 1505230, 'Mozer Machado', 'SENHA_INICIAL', 'MANUFATURA', NULL, 'SUPERVISOR GERAL'),
('Nayara Inacio', 'nayara.medeiros@chriscintos.com.br', 1506172, 'Nayara Inacio', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE'),
('Nobelia França', 'nobelia.alves@chriscintos.com.br', 1508392, 'Nobelia França', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE'),
('Pedro Alencar', 'pedro.silva@chriscintos.com.br', 1506081, 'Pedro Alencar', 'SENHA_INICIAL', 'TRATAMENTO SUPERFICIAL', NULL, 'ENCARREGADO'),
('Pedro Ivo Felix', 'pedro.sousa@chriscintos.com.br', 1507774, 'Pedro Ivo Felix', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE'),
('Pedro Romagnol', 'pedro.romagnol@chriscintos.com.br', 1507916, 'Pedro Romagnol', 'SENHA_INICIAL', 'MANUFATURA', NULL, 'GERENTE'),
('Renato Alves', 'renato.santos@chriscintos.com.br', 1507587, 'Renato Alves', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE'),
('Ricardo Marcante', 'ricardo.nunes@chriscintos.com.br', 1508447, 'Ricardo Marcante', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'ANALISTA'),
('Adelmo Mota', 'adelmo.mota@chriscintos.com.br', 36935, 'Adelmo Mota', 'SENHA_INICIAL', 'FUNDIÇÃO', NULL, 'SUPERVISOR'),
('Ailton Viezzer', 'ailton.viezzer@chriscintos.com.br', 1507140, 'Ailton Viezzer', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'SUPERVISOR'),
('Alessandra Gomes', 'alessandra.costa@chriscintos.com.br', 1506152, 'Alessandra Gomes', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE'),
('Alex Boneti', 'alex.boneti@chriscintos.com.br', 1508469, 'Alex Boneti', 'SENHA_INICIAL', 'ESTAMPARIA', NULL, 'ENCARREGADO'),
('Alisson Xavier', 'alisson.lima@chriscintos.com.br', 1508091, 'Alisson Xavier', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE'),
('Ana Paula do Nascimento', 'ana.souza@chriscintos.com.br', 1507038, 'Ana Paula do Nascimento', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE'),
('Anderson Gonçalves', 'anderson.santos@chriscintos.com.br', 1507350, 'Anderson Gonçalves', 'SENHA_INICIAL', 'MON RETRATOR', NULL, 'ENCARREGADO'),
('Andrea Carla', 'andrea.carla@chriscintos.com.br', 1505749, 'Andrea Carla', 'SENHA_INICIAL', 'MON RETRATOR', NULL, 'ENCARREGADO'),
('Brenda Carolina', 'brenda.silva@chriscintos.com.br', 1506638, 'Brenda Carolina', 'SENHA_INICIAL', 'EXCELÊNCIA OPERACIONAL', NULL, 'ANALISTA'),
('Bruno Moraes', 'bruno.souza@chriscintos.com.br', 1507357, 'Bruno Moraes', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'ANALISTA'),
('Carlos Barbosa', 'carlos.barbosa@chriscintos.com.br', 40878, 'Carlos Barbosa', 'SENHA_INICIAL', 'FUNDIÇÃO', NULL, 'ENCARREGADO'),
('Cesar Maciel', 'cesar.maciel@chriscintos.com.br', 34088, 'Cesar Maciel', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'SUPERVISOR'),
('Christos Junior', 'christosj@chriscintos.com.br', 1, 'Christos Junior', 'SENHA_INICIAL', 'PRESIDÊNCIA', NULL, 'PRESIDENTE'),
('Daniela Lins', 'daniela.lins@chriscintos.com.br', 1506178, 'Daniela Lins', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE'),
('Debora da Silva', 'debora.oliveira@chriscintos.com.br', 1505700, 'Debora da Silva', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'ANALISTA'),
('Eduardo de Souza', 'eduardo.souza@chriscintos.com.br', 1506811, 'Eduardo de Souza', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE'),
('Eduardo Lopes', 'eduardo.lopes@chriscintos.com.br', 1506162, 'Eduardo Lopes', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'SUPERVISOR GERAL'),
('Elio Marques', 'elio.oliveira@chriscintos.com.br', 1507286, 'Elio Marques', 'SENHA_INICIAL', 'MON RETRATOR', NULL, 'SUPERVISOR'),
('Eneas Alexandre', 'eneas.luz@chriscintos.com.br', 1505386, 'Eneas Alexandre', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE'),
('Eulina Lucena', 'eulina.lucena@chriscintos.com.br', 1500423, 'Eulina Lucena', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE'),
('Everton Vasconcelos', 'everton.vasconcelos@chriscintos.com.br', 1509453, 'Everton Vasconcelos', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE'),
('Fabio Baurilha', 'fabio.pereira@chriscintos.com.br', 1507001, 'Fabio Baurilha', 'SENHA_INICIAL', 'MON RETRATOR', NULL, 'ENCARREGADO'),
('Fabio Moreira', 'fabio.moreira@chriscintos.com.br', 1506905, 'Fabio Moreira', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE'),
('Felipe Lopes', 'felipe.lopes@chriscintos.com.br', 1506940, 'Felipe Lopes', 'SENHA_INICIAL', 'MON RETRATOR', NULL, 'ENCARREGADO'),
('Fernando Fagundes', 'fernando.fagundes@chriscintos.com.br', 1507839, 'Fernando Fagundes', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'SUPERVISOR'),
('Fernando Tenaglia', 'fernando.tenaglia@chriscintos.com.br', 111644, 'Fernando Tenaglia', 'SENHA_INICIAL', 'TRATAMENTO SUPERFICIAL', NULL, 'ENCARREGADO'),
('Franklin Santana', 'franklin.santana@chriscintos.com.br', 1507382, 'Franklin Santana', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'ANALISTA'),
('Giovanna Novais', 'giovanna.souza@chriscintos.com.br', 1507050, 'Giovanna Novais', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE'),
('Hailton Pereira', 'hailton.filho@chriscintos.com.br', 1507387, 'Hailton Pereira', 'SENHA_INICIAL', 'ESTAMPARIA', NULL, 'SUPERVISOR'),
('Humberto Bezerra', 'humberto.silva@chriscintos.com.br', 1507556, 'Humberto Bezerra', 'SENHA_INICIAL', 'MON RETRATOR', NULL, 'ENCARREGADO'),
('Jefferson Oliveira', 'jefferson.santos@chriscintos.com.br', 1507885, 'Jefferson Oliveira', 'SENHA_INICIAL', 'EXCELÊNCIA OPERACIONAL', NULL, 'ANALISTA'),
('João Luis', 'joao.silva@chriscintos.com.br', 30775, 'João Luis', 'SENHA_INICIAL', 'MANUFATURA', NULL, 'SUPERVISOR GERAL'),
('João Viana', 'joao.viana@chriscintos.com.br', 28380, 'João Viana', 'SENHA_INICIAL', 'TECELAGEM / TINTURARIA', NULL, 'ENCARREGADO'),
('José Guerra', 'jose.guerra@chriscintos.com.br', 1506750, 'José Guerra', 'SENHA_INICIAL', 'INJETORA', NULL, 'ENCARREGADO'),
('Junior Barbosa', 'junior.barbosa@chriscintos.com.br', 1506271, 'Junior Barbosa', 'SENHA_INICIAL', 'MANUFATURA', NULL, 'SUPERVISOR GERAL'),
('Jussara Marques', 'jussara.nascimento@chriscintos.com.br', 1504756, 'Jussara Marques', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE'),
('Kauan Sapattero', 'kauan.sapattero@chriscintos.com.br', 1507898, 'Kauan Sapattero', 'SENHA_INICIAL', 'MON RETRATOR', NULL, 'ENCARREGADO'),
('Larissa Kauana', 'larissa.santos@chriscintos.com.br', 1506885, 'Larissa Kauana', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE'),
('Leilane Cristine', 'leilane.oliveira@chriscintos.com.br', 1504350, 'Leilane Cristine', 'SENHA_INICIAL', 'ENG. QUALIDADE', NULL, 'AUDITOR DA QUALIDADE');